cd /app
python3 /app/app.py