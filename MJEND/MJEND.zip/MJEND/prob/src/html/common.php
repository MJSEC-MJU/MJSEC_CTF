<?php

$action = isset($_GET["action"]) ? $_GET["action"] : "";
$arg = $_GET["arg"] ?? "";